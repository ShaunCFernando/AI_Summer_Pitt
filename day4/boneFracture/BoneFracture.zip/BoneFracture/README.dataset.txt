# BoneFracture > 2025-06-11 2:36pm
https://universe.roboflow.com/aisummerschool2024-xa7p8/bonefracture-amjeh

Provided by a Roboflow user
License: CC BY 4.0

